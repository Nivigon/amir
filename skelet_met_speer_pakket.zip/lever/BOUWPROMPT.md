# Opdracht: skelet met speer, dat instort als de speer eruit wordt getrokken

Bouw dit in het bestaande spel "Amir, King of Africa" (2D side-scrolling platformer,
één HTML-bestand). Alle beelden zitten al kant en klaar in de map bij deze opdracht.
Er hoeft niets getekend of berekend te worden, alleen neerzetten en afspelen.

## Wat het moet doen

Er staat een skelet in het decor met een speer dwars door zijn borstkas. De speler kan
de speer eruit trekken. Zodra dat gebeurt verdwijnt de speer, speelt de instortanimatie
af, en blijft er een hoopje botten liggen.

## Bestanden

```
skelet_met_speer.png        1097 x 764   toestand 1, staat er gewoon
instorten/instort_sheet.png              de animatie, 30 frames in een sprite sheet
                                         6 kolommen, 5 rijen, elk vak 1124 x 837
instorten/instorten.json                 formaat, framecount, fps en uitlijning
skelet_ingestort.png        1124 x 837   toestand 2, gelijk aan het laatste frame
skeletvalt.mp3                           het geluid van het instorten
```

Het stof zit al in de frames gebakken. Transparante PNG's, dus ze composeren zo over je
achtergrond.

Zet `skeletvalt.mp3` bij de andere geluidsbestanden van het spel, in dezelfde map en met
dezelfde manier van inladen als de geluiden die er al zijn. Maak er geen nieuwe map voor
aan en verzin geen eigen pad.

## Schaal en uitlijning

Alles staat op één gedeelde schaal. Vermenigvuldig met **0,19** en je zit op spelformaat.
Amir is 237 pixels hoog in het spel, dat is het ijkpunt. Het zittende skelet wordt dan
145 pixels hoog.

De grondlijn:

- in `skelet_met_speer.png` ligt de grond op y = 764, dus de onderrand
- in de instortframes ligt de grond op y = 753 (staat ook in `instorten.json`)

De twee beelden hebben een verschillend formaat omdat de speer en de rollende schedel
buiten het skelet uitsteken. Om ze op dezelfde plek te houden gebruik je het ankerpunt
uit `instorten.json`:

```
skelet_met_speer.png     linkerbovenhoek van het skelet zit op  271, 0
instortframes            linkerbovenhoek van het skelet zit op  299, -1
```

Teken je beide met de linkerbovenhoek van het skelet op hetzelfde punt, dan blijft het
skelet exact staan bij de wissel en zie je geen sprong.

## Afspelen

1. Normaal staat `skelet_met_speer.png` in beeld.
2. De speler trekt de speer eruit. Laat de speer verdwijnen en voeg hem toe aan de
   inventaris.
3. Snijd de 30 frames uit de sheet (6 kolommen, 5 rijen, elk vak 1124 x 837, lezen van
   linksboven naar rechts) en speel ze af op **25 frames per seconde**, dat is 1,2 seconde. One-shot,
   geen lus. Start op frame 0 tegelijk `skeletvalt.mp3`.
4. Daarna blijft `skelet_ingestort.png` staan, oftewel het laatste frame.

Het geluid start dus op hetzelfde moment als het eerste frame, niet bij de klap. De klap
zit al in het geluid zelf. Speel het maar één keer af, ook als de speler meerdere
skeletten in beeld heeft: laat een tweede instorting het geluid opnieuw starten in plaats
van er een tweede overheen te leggen.

## De schedel verder laten rollen

Voor als de speler er later tegenaan schopt, of als hij van een richel af rolt.

```
skelet_ingestort_zonder_schedel.png   de stapel, zonder de schedel
schedel.png                           228 x 225, de losse schedel
```

Teken na de instortanimatie de stapel zonder schedel, en de schedel daar los overheen.
Zijn eindstand uit de animatie staat in `instorten.json`:

```
draaipunt in de sprite                 96, 111
draaipunt in skeletcoordinaten        458, 592
hoek                                  126 graden
straal                                 58
```

Rol je hem verder, koppel de draaiing dan aan de afgelegde afstand:

```
hoek = 126 + graden(verplaatsing_in_pixels / 58)
```

Dus 58 pixels naar rechts is ongeveer 57 graden extra draaiing. Doe je dat niet, dan
glijdt de schedel over de grond in plaats van te rollen, en dat zie je meteen.

Laat hem afremmen met een wrijvingsfactor rond 0,90 per frame en stoppen onder de 8
pixels per seconde. Elke twee frames een klein stofwolkje op het rolspoor.

## Schaduw

Onder het skelet hoort een zachte grondschaduw. Niet een donkerbruine vlek eroverheen,
maar de grond vermenigvuldigen met (0,74 , 0,80 , 0,91). Rood zakt het meest, blauw blijft
bijna gelijk, dan wordt zand donkerder zonder grijs te worden.

Vorm: platte ellips, hoogte ongeveer 17 procent van de breedte, 1,1 keer zo breed als het
object, en 16 procent van de breedte naar links verschoven. De zon staat in dit level
rechtsboven, dat zie je aan de schaduw naast de speerpaal in het decor.

Laat de schaduw tijdens het instorten meekrimpen met de stapel, anders blijft er een
grote vlek liggen onder een klein hoopje.

## Optioneel: wapperend doek

Wil je het blauwe doek aan de speer laten bewegen zolang de speer er nog in zit, gebruik
dan niet `skelet_met_speer.png` maar teken in vier lagen op exact dezelfde plek:

1. `skelet.png`
2. `speer_zonder_doek.png`, geschaald met 0,65 en 240 graden met de klok mee gedraaid
3. `skelet_voorste_botten.png`
4. het huidige doekframe uit `doek/`, met dezelfde schaal en hoek als de speer

Die derde laag is niet optioneel binnen deze variant. Zonder die stap ligt de speer op
het skelet in plaats van erdoorheen: de ribben aan de voorkant en het schouderblad horen
over de schacht heen, de wervelkolom en de verre arm eronder.

Het instekpunt van de speer ligt op 250, 300 in de coördinaten van het skelet, en de punt
600 pixels verder langs die hoek. Die waarden staan in `onderdelen.json` onder `speer`.

Het doek loopt op ongeveer 12 frames per seconde en de lus is naadloos.

## Optioneel: zelf aan de animatie sleutelen

In `delen/` staan de negen losse botdelen met hun draaipunten, de ouder-kindrelaties en
de eindwaarden van deze animatie, plus de valcurve. Daarmee kun je de instorting
naspelen of aanpassen. Alleen nodig als je iets anders wil dan wat er nu uit komt.
