SKELET MET SPEER, INSTORTEND
============================

  BOUWPROMPT.md                 plak dit bij Claude in je code-project

  skelet_met_speer.png          toestand 1, 1097 x 764
  instorten/instort_sheet.png   de animatie, 30 frames in een sheet van 6 x 5, 25 fps

  instorten/instorten.json      formaat, framecount, fps en uitlijning
  skelet_ingestort.png          toestand 2, gelijk aan het laatste frame
  skelet_ingestort_zonder_schedel.png  dezelfde stapel zonder schedel
  schedel.png                   de losse schedel, om verder te laten rollen

  skeletvalt.mp3                LET OP: zit hier niet in, zelf toevoegen

  Stof zit al in de frames. Alles transparant, gewoon neerzetten en afspelen.

OPTIONEEL
  skelet.png, skelet_voorste_botten.png, speer_zonder_doek.png, doek/
    voor als je het doek aan de speer wil laten wapperen zolang hij erin zit
  delen/, onderdelen.json
    de negen losse botdelen met draaipunten, voor als je de animatie wil aanpassen

SCHAAL
  Alles op een gedeelde schaal, spelformaat is x0,19.
  Amir 237 px hoog, zittend skelet 145 px.

UITLIJNING
  skelet_met_speer.png   linkerbovenhoek van het skelet op  271, 0
  instortframes          linkerbovenhoek van het skelet op  299, -1
  Houd die punten gelijk en het skelet springt niet bij de wissel.
