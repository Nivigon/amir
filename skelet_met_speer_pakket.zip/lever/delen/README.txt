SKELET - negen losse delen voor het instorten
=============================================

Hele skelet: 826 x 764 px. De grond ligt op y = 754.
Zet elk deel op zijn offset en het skelet staat weer compleet.

  bestand                        off x off y  breed  hoog   draaipunt  ouder               dx    dy  hoek
  skelet_1_schedel.png             62     1    228   225    158,112  -                     0     0     0
  skelet_2_romp.png                18   203    234   311    112,462  -                    62   180    30
  skelet_3_bekken.png               1   510    150   193    108,596  -                     0     0     0
  skelet_4_bovenarm_dichtbij.png  221   258     92   233    248,276  -                   -10   450  -160
  skelet_5_bovenarm_ver.png        62   245     60   258     88,266  -                    52   300   -40
  skelet_6_bovenbenen.png         160   488    251   151    178,556  bekken                0     0     0
  skelet_7_onderbenen.png         378   475    447   288    400,518  bovenbenen            0     0     0
  skelet_8_onderarm_dichtbij.png  175   477    336   217    288,486  bovenarm_dichtbij     0     0  -115
  skelet_9_onderarm_ver.png        67   496    245   258     92,495  bovenarm_ver          0     0  -130

TEKENVOLGORDE (achter naar voor)
  bovenarm_ver, onderarm_ver, onderbenen, bovenbenen, bekken, romp, onderarm_dichtbij, bovenarm_dichtbij, schedel

KETTING
  bovenbenen        hangt aan bekken
  onderbenen        hangt aan bovenbenen
  onderarm_ver      hangt aan bovenarm_ver
  onderarm_dichtbij hangt aan bovenarm_dichtbij

  Reken van boven naar beneden: draai eerst de ouder, verplaats dan het draaipunt van
  het kind mee met die draaiing, en draai daarna pas het kind. De hoek van het kind in
  de tabel is zijn eigen draaiing bovenop die van de ouder.

WAT ER GEBEURT
  Bekken, bovenbenen en onderbenen blijven precies staan. Die lagen al op de grond,
  dus die hebben niets om naar toe te vallen. Alleen het bovenlichaam stort in.
  De ribbenkast kantelt voorover om de onderrug en komt op het bovenbeen te liggen.
  De armen zakken naast de stapel. De schedel rolt van de borst af naar voren.

TIMING
  Alles begint tegelijk en is in 13 frames beneden.
  Valcurve: tot 0,74 van de tijd versnellen met (t/0,74)^2,2, daarna een naveer van
  9 procent die uitdempt.

SCHEDEL
  Valt mee met de rest tot dx 176, dy 480, hoek 74.
  Rolt daarna als enige nog door naar dx 300 en hoek 126, in 16 frames,
  met een uitloop van 1-(1-q)^2,4. Elke twee frames een klein stofwolkje op het rolspoor.

STOF
  Kleur 238,210,172. De wolkjes groeien met de wortel van hun leeftijd, drijven omhoog
  en vervagen. De grote wolk komt op het frame van de klap.
