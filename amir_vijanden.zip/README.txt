Amir - vijandpakket (testronde)
================================

Drie kleurvarianten van dezelfde zwaardvechter, elk met zes animatiesets:
  idle, dreigen, rennen, slag, geraakt, dood

Mappen:
  basisacteur/    rode tunic (de bron)
  vijand_blauw/   blauwe tunic
  vijand_groen/   groene tunic

Alleen de tunic-kleur verschilt; verder identiek personage en identieke
frames. Meer varianten (andere kleuren, opzetstukken zoals een hoofddoek)
komen later.

Per set:
  <acteur>/<set>/<set>_NN.png   losse transparante frames op gedeeld canvas
  <acteur>/metadata.json        canvas, grondlijn, anker_x, fps, loop, framebereiken

Alle sets van een acteur delen hetzelfde canvas (1150x981), dezelfde
grondlijn (rij 925) en dezelfde anker_x (443), zodat de acteur niet
verspringt bij het wisselen van animatie. De drie acteurs hebben identieke
maten. Spiegel in code voor vijanden die naar links kijken.

Set-notities:
- idle, dreigen, rennen: loop.
- slag: one-shot. spannen -> klap (raak_frames) -> herstel. Zie metadata.
- geraakt: 1 frame (pijnpose). Toon een paar gameframes met een witte flits
  en een kleine knockback, daarna terug naar idle of dreigen.
- dood: one-shot. Laatste frame is het lichaam dat blijft liggen.

Hiteffecten (flits, screenshake, zwaaiboog) horen in de gamecode.
